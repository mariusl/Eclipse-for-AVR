/*
 * main.cpp
 *
 *  Created on: 23 Jun 2011
 *      Author: Marius
 */
#include <Wprogram.h>
// Uncomment if you need it for C++ style new/delete and pointer protection
#include "cppsupport.h"
int ledPin = 13;
void setup()
{
	 pinMode(ledPin, OUTPUT);      // sets the digital pin as output
}

void loop(void)
{
	do{
		digitalWrite(ledPin, HIGH);   // sets the LED on
		delay(100);                  // waits for a second
		digitalWrite(ledPin, LOW);    // sets the LED off
		delay(100);                  // waits for a second
	}while(1);
}

int main(void)
{
   init();

   setup();


      loop();

   return(0);
}
